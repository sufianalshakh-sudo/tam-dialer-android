package jo.tam.dialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.telecom.InCallService
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity: AppCompatActivity() {
    private lateinit var roleManager: RoleManager
    private lateinit var roleText: TextView
    private lateinit var loginText: TextView
    private lateinit var callText: TextView

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { updateRole() }
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { updateRole() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        roleManager = getSystemService(RoleManager::class.java)
        roleText=findViewById(R.id.txtRoleStatus)
        loginText=findViewById(R.id.txtLoginStatus)
        callText=findViewById(R.id.txtCallState)

        findViewById<Button>(R.id.btnDefaultDialer).setOnClickListener { requestRole() }
        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            val email=findViewById<EditText>(R.id.email).text.toString().trim()
            val pass=findViewById<EditText>(R.id.password).text.toString()
            loginText.text="جاري تسجيل الدخول..."
            TamApi.login(this,email,pass){_,msg->runOnUiThread{loginText.text=msg}}
        }
        findViewById<Button>(R.id.btnCall).setOnClickListener {
            val num=findViewById<EditText>(R.id.phoneNumber).text.toString().trim()
            if(num.isBlank()) return@setOnClickListener
            if(ActivityCompat.checkSelfPermission(this,Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){
                requestPermissions(); return@setOnClickListener
            }
            (getSystemService(TELECOM_SERVICE) as TelecomManager).placeCall(Uri.parse("tel:$num"),Bundle())
            callText.text="بدأ الاتصال: $num"
        }
        findViewById<Button>(R.id.btnAnswer).setOnClickListener { TamInCallService.answerCurrent(); callText.text="تم إرسال أمر الرد" }
        findViewById<Button>(R.id.btnReject).setOnClickListener { TamInCallService.rejectCurrent(); callText.text="تم إرسال أمر الرفض" }

        findViewById<Button>(R.id.btnRoleDiagnostics).setOnClickListener {
            runRoleDiagnostics()
        }

        requestPermissions()
        updateRole()
        loginText.text=if(SessionStore.token(this).isNullOrBlank()) "غير مسجل" else "مسجل في تم"
    }

    override fun onResume(){ super.onResume(); updateRole(); callText.text=if(TamInCallService.currentCall==null)"لا توجد مكالمة حالية" else "هناك مكالمة حالية" }

    private fun requestRole(){
        if(roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) && !roleManager.isRoleHeld(RoleManager.ROLE_DIALER))
            roleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER))
        else updateRole()
    }
    private fun updateRole(){
        roleText.text=if(roleManager.isRoleHeld(RoleManager.ROLE_DIALER))"✓ تم هو تطبيق الهاتف الافتراضي" else "تم ليس تطبيق الهاتف الافتراضي بعد"
    }
    private fun runRoleDiagnostics() {
        val pm = packageManager
        val dialIntent = Intent(Intent.ACTION_DIAL)
        val dialTelIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:123"))
        val bareMatches = pm.queryIntentActivities(dialIntent, PackageManager.MATCH_DEFAULT_ONLY)
            .any { it.activityInfo.packageName == packageName }
        val telMatches = pm.queryIntentActivities(dialTelIntent, PackageManager.MATCH_DEFAULT_ONLY)
            .any { it.activityInfo.packageName == packageName }

        val svcIntent = Intent("android.telecom.InCallService")
        val svcMatches = pm.queryIntentServices(svcIntent, PackageManager.MATCH_ALL)
            .any {
                it.serviceInfo.packageName == packageName &&
                it.serviceInfo.permission == Manifest.permission.BIND_INCALL_SERVICE &&
                it.serviceInfo.metaData?.getBoolean("android.telecom.IN_CALL_SERVICE_UI", false) == true
            }

        val available = roleManager.isRoleAvailable(RoleManager.ROLE_DIALER)
        val held = roleManager.isRoleHeld(RoleManager.ROLE_DIALER)

        findViewById<TextView>(R.id.txtRoleDiagnostics).text =
            "ROLE_DIALER متاح: $available\n" +
            "ACTION_DIAL: $bareMatches\n" +
            "ACTION_DIAL tel: $telMatches\n" +
            "InCallService صالح: $svcMatches\n" +
            "تم هو الافتراضي: $held"
    }

    private fun requestPermissions(){
        val p=mutableListOf(Manifest.permission.CALL_PHONE,Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_CALL_LOG,Manifest.permission.WRITE_CALL_LOG,Manifest.permission.ANSWER_PHONE_CALLS)
        if(android.os.Build.VERSION.SDK_INT>=33) p+=Manifest.permission.POST_NOTIFICATIONS
        permissionLauncher.launch(p.toTypedArray())
    }
}

package jo.tam.dialer
object SupabaseConfig {
    const val BASE_URL = "https://fqbirnxghipdqopxbtue.supabase.co"
    const val PUBLISHABLE_KEY = "sb_publishable_-RmNSg9a4mfSVGAxvX0P_w_DXyoc8zt"
    const val PHONE_EVENTS_URL = "$BASE_URL/functions/v1/tam-phone-events"
}

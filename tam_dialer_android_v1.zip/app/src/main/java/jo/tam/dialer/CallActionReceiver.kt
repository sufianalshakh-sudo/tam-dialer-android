package jo.tam.dialer
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        when(intent?.action) {
            "ANSWER" -> TamInCallService.answerCurrent()
            "REJECT" -> TamInCallService.rejectCurrent()
        }
    }
}

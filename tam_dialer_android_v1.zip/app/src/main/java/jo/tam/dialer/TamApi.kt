package jo.tam.dialer

import android.content.Context
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object TamApi {
    private val executor = Executors.newCachedThreadPool()

    fun login(context: Context, email: String, password: String, cb: (Boolean, String) -> Unit) {
        executor.execute {
            try {
                val c = (URL("${SupabaseConfig.BASE_URL}/auth/v1/token?grant_type=password").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                }
                val body = JSONObject().put("email", email).put("password", password)
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val text = readResponse(c)
                if (c.responseCode in 200..299) {
                    val token = JSONObject(text).getString("access_token")
                    SessionStore.saveToken(context, token)
                    cb(true, "تم تسجيل الدخول")
                } else cb(false, "فشل الدخول")
            } catch (e: Exception) { cb(false, e.message ?: "خطأ") }
        }
    }

    fun createCallEvent(context: Context, direction: String, phone: String?, state: String, cb: (String?) -> Unit) {
        val token = SessionStore.token(context) ?: return cb(null)
        executor.execute {
            try {
                val b = JSONObject().put("action","create").put("direction",direction)
                    .put("phone_number", phone ?: JSONObject.NULL).put("state",state)
                    .put("device_id", android.os.Build.MODEL)
                cb(post(token,b)?.optString("event_id"))
            } catch (_: Exception) { cb(null) }
        }
    }

    fun updateCallEvent(context: Context, eventId: String?, state: String, extra: JSONObject = JSONObject()) {
        if (eventId.isNullOrBlank()) return
        val token = SessionStore.token(context) ?: return
        executor.execute {
            try {
                val b = JSONObject().put("action","update").put("event_id",eventId).put("state",state)
                extra.keys().forEach { b.put(it, extra.get(it)) }
                post(token,b)
            } catch (_: Exception) {}
        }
    }

    private fun post(token: String, body: JSONObject): JSONObject? {
        val c = (URL(SupabaseConfig.PHONE_EVENTS_URL).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("Content-Type","application/json")
            setRequestProperty("Authorization","Bearer $token")
            setRequestProperty("apikey",SupabaseConfig.PUBLISHABLE_KEY)
        }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val text = readResponse(c)
        return if (c.responseCode in 200..299) JSONObject(text) else null
    }

    private fun readResponse(c: HttpURLConnection): String {
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        return BufferedReader(InputStreamReader(stream)).use { it.readText() }
    }
}

package jo.tam.dialer
import android.content.Context
object SessionStore {
    private const val PREFS = "tam_session"
    private const val KEY_TOKEN = "access_token"
    fun saveToken(context: Context, token: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_TOKEN, token).apply()
    }
    fun token(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TOKEN, null)
}

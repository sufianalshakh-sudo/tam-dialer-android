package jo.tam.dialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.telecom.Call
import android.telecom.InCallService
import android.telecom.VideoProfile
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.util.Collections
import java.util.WeakHashMap

class TamInCallService : InCallService() {

    data class Tracked(var eventId: String? = null, var answeredAt: Long? = null, val startedAt: Long = System.currentTimeMillis())

    companion object {
        @Volatile var currentCall: Call? = null
        private val tracked = Collections.synchronizedMap(WeakHashMap<Call,Tracked>())
        fun answerCurrent() { currentCall?.answer(VideoProfile.STATE_AUDIO_ONLY) }
        fun rejectCurrent() { currentCall?.reject(false,null) }
    }

    override fun onCreate() { super.onCreate(); createChannel() }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        currentCall = call
        val number = call.details.handle?.schemeSpecificPart
        val direction = if (call.details.callDirection == Call.Details.DIRECTION_INCOMING) "inbound" else "outbound"
        val trackedCall = Tracked()
        tracked[call] = trackedCall
        TamApi.createCallEvent(this, direction, number, stateName(call.state)) { trackedCall.eventId = it }

        call.registerCallback(object: Call.Callback() {
            override fun onStateChanged(c: Call, state: Int) {
                val t = tracked[c] ?: return
                val extra = JSONObject()
                if (state == Call.STATE_ACTIVE && t.answeredAt == null) {
                    t.answeredAt = System.currentTimeMillis()
                    extra.put("answered_at", java.time.Instant.ofEpochMilli(t.answeredAt!!).toString())
                }
                if (state == Call.STATE_DISCONNECTED) {
                    val end = System.currentTimeMillis()
                    val start = t.answeredAt ?: t.startedAt
                    extra.put("ended_at", java.time.Instant.ofEpochMilli(end).toString())
                    extra.put("duration_seconds", ((end-start)/1000).toInt())
                }
                TamApi.updateCallEvent(this@TamInCallService,t.eventId,stateName(state),extra)
            }
        })
        showNotification(number ?: "رقم غير معروف", direction)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        if (currentCall == call) currentCall = null
        tracked.remove(call)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(1001)
    }

    private fun stateName(s:Int)=when(s){
        Call.STATE_NEW -> "new"
        Call.STATE_DIALING -> "dialing"
        Call.STATE_RINGING -> "ringing"
        Call.STATE_ACTIVE -> "active"
        Call.STATE_HOLDING -> "holding"
        Call.STATE_DISCONNECTED -> "disconnected"
        Call.STATE_CONNECTING -> "connecting"
        else -> "state_$s"
    }

    private fun showNotification(number:String,direction:String){
        val answer = PendingIntent.getBroadcast(this,1,Intent(this,CallActionReceiver::class.java).setAction("ANSWER"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val reject = PendingIntent.getBroadcast(this,2,Intent(this,CallActionReceiver::class.java).setAction("REJECT"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this,"tam_calls")
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(if(direction=="inbound") "مكالمة واردة" else "مكالمة صادرة")
            .setContentText(number)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .addAction(android.R.drawable.sym_action_call,"رد",answer)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel,"رفض",reject)
            .build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1001,n)
    }

    private fun createChannel(){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            val c=NotificationChannel("tam_calls","مكالمات تم",NotificationManager.IMPORTANCE_HIGH)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c)
        }
    }
}

# Tam Dialer Android V2

نسخة Proof of Concept لاختبار استخدام هاتف Android نفسه كواجهة اتصال لـ«تم».

### تعمل الآن
- طلب جعل «تم» تطبيق الهاتف الافتراضي.
- بدء مكالمة من شريحة الهاتف.
- التقاط المكالمات الواردة والصادرة عبر Android InCallService.
- رد / رفض.
- تسجيل الدخول إلى Supabase.
- إرسال أحداث المكالمة إلى سيرفر تم `tam-phone-events`.

### لا تعمل بعد
- صوت الذكاء الصناعي داخل مكالمة SIM نفسها.
- تسجيل صوت المكالمة.
- الربط الصوتي مع Autocalls/SIP.

هذه المرحلة مقصودها إثبات التحكم بالمكالمة على جهاز Samsung أولاً.
بعد نجاحها ننتقل لطبقة الصوت AI.

Package: jo.tam.dialer
JDK: 17
Min Android: 10 (API 29)


## V2 fix
- Added the required bare `Intent.ACTION_DIAL` intent filter (without a `tel:` data constraint).
- Keeps the `ACTION_DIAL` + `tel:` filter and `InCallService`.
- This is required for Android/Samsung to list the app as eligible for the default Phone/Dialer role.
